<?php
	return array(
	'articles/:aid' => 'Article/index',
	'lists/:typeid' => 'List/index',
	'photos' => 'List/photo',
	'votes/:id' => 'Vote/index',
	's'=> 'Index/search',
	);
?>