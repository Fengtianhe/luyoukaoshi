var TECSS={
	main:"te_main",
	toolbar_box:"te_toolbar_box",
	toolbar:"te_toolbar",
	group:"te_group",
	line:"te_line",
	btn:"te_btn",
	btnpre:"te_btn_",
	bottom:"te_bottom",
	resizeCenter:"te_resize_center",
	resizeLeft:"te_resize_left",
	dialog:"te_dialog",
	dialogCloseBtn:"te_close",
	dialogOkBtn:"te_ok",
	noRight:"te_noright",
	disable:"te_disable",
	mouseover:"te_mouseover",
	btnWidth:32,
	btnHeight:17,
	lineWidth:7,

	fulled:"te_fulled",//ȫ��ʱȫ����ť��ʽ
	sourceMode:"te_source"//Դ��ģʽʱ�İ�ť��ʽ

};
